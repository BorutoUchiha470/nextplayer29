package dev.anilbeesetti.nextplayer.feature.videopicker.screens.mediapicker

import android.Manifest
import android.app.Application
import android.content.pm.PackageManager
import androidx.activity.ComponentActivity
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsFocused
import androidx.compose.ui.test.junit4.v2.createAndroidComposeRule
import androidx.compose.ui.test.longClick
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.onRoot
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performKeyInput
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.pressKey
import androidx.compose.ui.test.requestFocus
import androidx.core.net.toUri
import androidx.lifecycle.Lifecycle
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import dev.anilbeesetti.nextplayer.core.domain.MediaHolder
import dev.anilbeesetti.nextplayer.core.model.ApplicationPreferences
import dev.anilbeesetti.nextplayer.core.model.Folder
import dev.anilbeesetti.nextplayer.core.model.MediaViewMode
import dev.anilbeesetti.nextplayer.core.model.PlaylistSummary
import dev.anilbeesetti.nextplayer.core.model.PlaylistType
import dev.anilbeesetti.nextplayer.core.model.Video
import dev.anilbeesetti.nextplayer.core.ui.R
import dev.anilbeesetti.nextplayer.core.ui.base.DataState
import dev.anilbeesetti.nextplayer.core.ui.components.LocalTopLevelFabSetter
import dev.anilbeesetti.nextplayer.core.ui.components.TopLevelFabState
import dev.anilbeesetti.nextplayer.core.ui.theme.NextPlayerTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config

@RunWith(AndroidJUnit4::class)
@Config(sdk = [36])
class MediaPickerScreenTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<ComponentActivity>()

    @Test
    fun rootResumeFabUsesAutomaticPlaylistInEveryViewMode() {
        assertResumeFabUsesAutomaticPlaylist(folderName = null)
    }

    @Test
    fun folderResumeFabUsesAutomaticPlaylistInEveryViewMode() {
        assertResumeFabUsesAutomaticPlaylist(folderName = "Movies")
    }

    private fun assertResumeFabUsesAutomaticPlaylist(folderName: String?) {
        val application = ApplicationProvider.getApplicationContext<Application>()
        shadowOf(application).grantPermissions(Manifest.permission.READ_MEDIA_VIDEO)
        val actions = mutableListOf<MediaPickerAction>()
        val video = Video.sample.copy(uriString = "content://media/external/video/media/2")
        var viewMode by mutableStateOf(MediaViewMode.FOLDERS)
        var rootFab: TopLevelFabState? = null
        val setFab: (String, TopLevelFabState?) -> Unit = { _, fab -> rootFab = fab }
        composeRule.setContent {
            CompositionLocalProvider(value = LocalTopLevelFabSetter provides setFab) {
                NextPlayerTheme {
                    MediaPickerScreenContent(
                        state = MediaPickerUiState(
                            folderName = folderName,
                            recentlyPlayedVideo = video,
                            preferences = ApplicationPreferences(mediaViewMode = viewMode),
                            mediaDataState = DataState.Success(
                                value = MediaHolder(
                                    videos = if (folderName == null &&
                                        viewMode != MediaViewMode.VIDEOS
                                    ) {
                                        emptyList()
                                    } else {
                                        listOf(
                                            Video.sample.copy(
                                                uriString =
                                                    "content://media/external/video/media/1",
                                            ),
                                            video,
                                        )
                                    },
                                    folders = listOf(
                                        element = Folder(
                                            name = "Movies",
                                            path = "/Movies",
                                            dateModified = 0,
                                        ),
                                    ),
                                ),
                            ),
                        ),
                        onAction = actions::add,
                    )
                }
            }
        }

        for (mode in MediaViewMode.entries) {
            composeRule.runOnIdle {
                viewMode = mode
                actions.clear()
            }
            if (folderName == null) {
                composeRule.runOnIdle { checkNotNull(value = rootFab).onClick() }
            } else {
                composeRule.onNodeWithContentDescription(label = "Play").performClick()
            }
            // A single-video launch lets the player build the sorted queue; an explicit
            // one-item PlaySelectedItems queue disables that behavior.
            composeRule.runOnIdle {
                assertEquals(
                    "Resume in $mode",
                    listOf(MediaPickerAction.OnPlayVideo(video.uriString.toUri())),
                    actions,
                )
            }
        }
    }

    @Test
    @Config(qualifiers = "w960dp-h540dp-land-television")
    fun tvFolderFabUpReturnsToTheVideoInsteadOfSettings() {
        val application = ApplicationProvider.getApplicationContext<Application>()
        shadowOf(application).grantPermissions(Manifest.permission.READ_MEDIA_VIDEO)
        shadowOf(application.packageManager).setSystemFeature(
            PackageManager.FEATURE_LEANBACK,
            true,
        )
        val video = Video.sample.copy(
            nameWithExtension = "Clip.mp4",
            uriString = "content://video/1",
        )
        composeRule.setContent {
            NextPlayerTheme {
                MediaPickerScreenContent(
                    state = MediaPickerUiState(
                        folderName = "Movies",
                        mediaDataState = DataState.Success(
                            value = MediaHolder(
                                videos = listOf(element = video),
                                folders = emptyList(),
                            ),
                        ),
                    ),
                )
            }
        }

        composeRule.onNodeWithText(text = "Clip").requestFocus()
        composeRule.onNodeWithContentDescription(label = "Play").requestFocus()
        composeRule.onRoot().performKeyInput { pressKey(Key.DirectionUp) }
        composeRule.onNodeWithText(text = "Clip").assertIsFocused()
    }

    @Test
    fun loadingWithoutStoragePermissionShowsPermissionMessage() {
        val permissionMessage = ApplicationProvider.getApplicationContext<android.content.Context>()
            .getString(R.string.permission_not_granted)

        composeRule.setContent {
            NextPlayerTheme {
                MediaPickerScreenContent(
                    state = MediaPickerUiState(folderName = null),
                )
            }
        }

        composeRule.onNodeWithText(text = permissionMessage).assertIsDisplayed()
    }

    @Test
    fun grantingStoragePermissionFromSettingsStartsMediaCollection() {
        val actions = mutableListOf<MediaPickerAction>()
        composeRule.setContent {
            NextPlayerTheme {
                MediaPickerScreenContent(
                    state = MediaPickerUiState(folderName = null),
                    onAction = actions::add,
                )
            }
        }
        composeRule.waitForIdle()

        val application = ApplicationProvider.getApplicationContext<Application>()
        shadowOf(application).grantPermissions(Manifest.permission.READ_MEDIA_VIDEO)
        composeRule.activityRule.scenario.moveToState(Lifecycle.State.CREATED)
        composeRule.activityRule.scenario.moveToState(Lifecycle.State.RESUMED)
        composeRule.waitForIdle()

        assertTrue(MediaPickerAction.OnPermissionAccepted in actions)
    }

    @Test
    fun choosingPlaylistDispatchesActionAndExitsSelectionMode() {
        val actions = mutableListOf<MediaPickerAction>()
        val application = ApplicationProvider.getApplicationContext<Application>()
        shadowOf(application).grantPermissions(Manifest.permission.READ_MEDIA_VIDEO)
        var showPlaylistDialog by mutableStateOf(value = false)
        val video = Video.sample.copy(
            nameWithExtension = "Video.mp4",
            uriString = "content://video/1",
        )
        composeRule.setContent {
            NextPlayerTheme {
                MediaPickerScreenContent(
                    state = MediaPickerUiState(
                        folderName = null,
                        mediaDataState = DataState.Success(
                            value = MediaHolder(
                                folders = emptyList(),
                                videos = listOf(element = video),
                            ),
                        ),
                        playlists = listOf(
                            element = PlaylistSummary(
                                id = 7,
                                name = "Movies",
                                type = PlaylistType.LOCAL,
                                itemCount = 2,
                                lastRefreshedAt = null,
                            ),
                        ),
                        addToPlaylistState = AddToPlaylistState(
                            isVisible = showPlaylistDialog,
                            hasVideos = true,
                        ),
                    ),
                    onAction = actions::add,
                )
            }
        }

        composeRule.onNodeWithText(text = "Video").performTouchInput { longClick() }
        composeRule.onNodeWithText(text = "1 / 1 Selected").assertIsDisplayed()
        composeRule.runOnIdle { showPlaylistDialog = true }

        composeRule.onNodeWithText(text = "Choose a playlist").assertIsDisplayed()
        composeRule.onNodeWithText(text = "Create new playlist").assertIsDisplayed()
        composeRule.onNodeWithText(text = "Movies").performClick()

        assertTrue(MediaPickerAction.AddSelectionToPlaylist(playlistId = 7) in actions)
        composeRule.runOnIdle { showPlaylistDialog = false }
        composeRule.onNodeWithText(text = "1 / 1 Selected").assertDoesNotExist()
    }
}
