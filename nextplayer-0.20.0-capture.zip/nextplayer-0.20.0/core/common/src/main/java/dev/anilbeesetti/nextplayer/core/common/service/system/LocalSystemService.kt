package dev.anilbeesetti.nextplayer.core.common.service.system

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import dev.anilbeesetti.nextplayer.core.common.service.SuspendActivityResultLauncher
import dev.anilbeesetti.nextplayer.core.common.service.registerForSuspendActivityResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.koin.core.annotation.Single

@Single
class LocalSystemService(private val context: Context) : SystemService {
    private var pickDocumentTreeLauncher: SuspendActivityResultLauncher<Uri?, Uri?>? = null

    override fun initialize(activity: ComponentActivity) {
        val launcher = activity.registerForSuspendActivityResult(
            ActivityResultContracts.OpenDocumentTree(),
        )
        activity.lifecycle.addObserver(
            object : DefaultLifecycleObserver {
                override fun onStart(owner: LifecycleOwner) {
                    pickDocumentTreeLauncher = launcher
                }

                override fun onResume(owner: LifecycleOwner) {
                    pickDocumentTreeLauncher = launcher
                }

                override fun onStop(owner: LifecycleOwner) {
                    if (pickDocumentTreeLauncher === launcher) pickDocumentTreeLauncher = null
                }
            },
        )
    }

    override suspend fun pickFolder(): Uri? = withContext(Dispatchers.Main.immediate) {
        pickDocumentTreeLauncher?.launch(input = null)?.also { uri ->
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
                )
            }
        }
    }

    override fun getString(stringResId: Int): String = context.getString(stringResId)

    override fun getQuantityString(
        pluralsResId: Int,
        quantity: Int,
        vararg formatArgs: Any,
    ): String = context.resources.getQuantityString(
        pluralsResId,
        quantity,
        *formatArgs,
    )

    override fun showToast(text: String, duration: Int) {
        Toast.makeText(
            context,
            text,
            duration,
        ).show()
    }
}
